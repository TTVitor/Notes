function loadNotes() {
    return JSON.parse(localStorage.getItem('notes') || '[]');
  }
  
  function saveNotes(notes) {
    localStorage.setItem('notes', JSON.stringify(notes));
  }
  
  function renderNotes(filter = '') {
    const notesContainer = document.getElementById('notes');
    notesContainer.innerHTML = '';
    const notes = loadNotes();
  
    const filtered = notes.filter(note =>
      note.title.includes(filter) ||
      note.content.includes(filter) ||
      note.tags.some(tag => tag.includes(filter))
    );
  
    filtered.forEach(note => {
      const div = document.createElement('div');
      div.className = 'note';
      div.innerHTML = `
        <h3>${note.title}</h3>
        <div class="tags">Tags: ${note.tags.join(', ')}</div>
        <p>${note.content}</p>
        <button onclick="deleteNote('${note.id}')">Deletar</button>
      `;
      notesContainer.appendChild(div);
    });
  }
  
  function addNote() {
    const title = document.getElementById('title').value.trim();
    const content = document.getElementById('content').value.trim();
    const tags = document.getElementById('tags').value.split(',').map(t => t.trim()).filter(Boolean);
  
    if (!title || !content) {
      alert('Título e conteúdo são obrigatórios!');
      return;
    }
  
    const notes = loadNotes();
    notes.push({
      id: Date.now().toString(),
      title,
      content,
      tags
    });
  
    saveNotes(notes);
    document.getElementById('title').value = '';
    document.getElementById('content').value = '';
    document.getElementById('tags').value = '';
    renderNotes();
  }
  
  function deleteNote(id) {
    let notes = loadNotes();
    notes = notes.filter(note => note.id !== id);
    saveNotes(notes);
    renderNotes();
  }
  
  function searchNotes() {
    const keyword = document.getElementById('search').value.trim();
    renderNotes(keyword);
  }
  
  // Inicializa
  renderNotes();
  