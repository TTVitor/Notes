const fs = require('fs');
const path = require('path');

const notesFile = path.join(__dirname, 'notes.json');

function loadNotes() {
  try {
    const data = fs.readFileSync(notesFile, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    return [];
  }
}

function saveNotes(notes) {
  fs.writeFileSync(notesFile, JSON.stringify(notes, null, 2));
}

function addNote(title, content, tags = []) {
  const notes = loadNotes();
  const id = Date.now().toString();
  notes.push({ id, title, content, tags });
  saveNotes(notes);
  console.log('Nota adicionada com sucesso!');
}

function deleteNote(id) {
  let notes = loadNotes();
  const initialLength = notes.length;
  notes = notes.filter(note => note.id !== id);
  if (notes.length === initialLength) {
    console.log('Nota não encontrada.');
  } else {
    saveNotes(notes);
    console.log('Nota deletada com sucesso!');
  }
}

function searchNotes(keyword) {
  const notes = loadNotes();
  const results = notes.filter(note =>
    note.title.includes(keyword) ||
    note.content.includes(keyword) ||
    note.tags.some(tag => tag.includes(keyword))
  );

  if (results.length === 0) {
    console.log('Nenhuma nota encontrada com essa palavra-chave.');
  } else {
    console.log('Notas encontradas:\n');
    results.forEach(displayNote);
  }
}

function displayNote(note) {
  console.log(`ID: ${note.id}`);
  console.log(`Título: ${note.title}`);
  console.log(`Conteúdo: ${note.content}`);
  console.log(`Tags: ${note.tags.join(', ')}`);
  console.log('---');
}

function viewAllNotes() {
  const notes = loadNotes();
  if (notes.length === 0) {
    console.log('Nenhuma nota encontrada.');
  } else {
    notes.forEach(displayNote);
  }
}

// Exports
module.exports = {
  addNote,
  deleteNote,
  searchNotes,
  viewAllNotes
};
