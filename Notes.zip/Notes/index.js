const readline = require('readline');
const notes = require('./notes');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function showMenu() {
  console.log('\n📝 Gerenciador de Notas');
  console.log('1. Adicionar Nota');
  console.log('2. Deletar Nota');
  console.log('3. Procurar Nota por Palavra-chave');
  console.log('4. Ver Todas as Notas');
  console.log('5. Sair');
  rl.question('\nEscolha uma opção: ', handleMenu);
}

function handleMenu(option) {
  switch (option) {
    case '1':
      rl.question('Título: ', title => {
        rl.question('Conteúdo: ', content => {
          rl.question('Tags (separadas por vírgula): ', tagStr => {
            const tags = tagStr.split(',').map(t => t.trim());
            notes.addNote(title, content, tags);
            showMenu();
          });
        });
      });
      break;
    case '2':
      rl.question('ID da nota para deletar: ', id => {
        notes.deleteNote(id);
        showMenu();
      });
      break;
    case '3':
      rl.question('Palavra-chave: ', keyword => {
        notes.searchNotes(keyword);
        showMenu();
      });
      break;
    case '4':
      notes.viewAllNotes();
      showMenu();
      break;
    case '5':
      rl.close();
      break;
    default:
      console.log('Opção inválida.');
      showMenu();
      break;
  }
}

showMenu();
